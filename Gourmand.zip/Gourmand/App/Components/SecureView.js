
"use strict";

var React = require("react-native");
var {
    Component,
    StyleSheet,
    Text,
    View,
    ListView,
} = React;

class KitchenView extends Component {

    constructor(props) {
        console.log("I'm setting up SecureView");
        super(props);
        this.state = {
            id: this.props.id,
            token: this.props.token,
            kitchens: this.props.kitchens
        }
    }
};

var KitchenListItem = React.createClass({



  render: function(){
    return (
      <View>
        <Text>{this.props.kitchens}</Text>
      </View>
    )
  },

  gotData: function(){
    console.log("This is the row number selected" + this.props.id)
  },
  getData: function(){
    fetch('https://gourmand.herokuapp.com/kitchen/' + this.props.id).then(this.gotData)
  }
})

var KitchenList = React.createClass({



  componentDidMount: function(){
    this.kitchensLoaded;
  },
     fetchData: function() {
       fetch(REQUEST_URL)
        .then((response) => response.json())
        .then((responseData) => {
          console.log(responseData);
          this.setState({
            dataSource: this.state.dataSource.cloneWithRows(responseData),
            loaded: true,
          });
        })
      .catch((error) => {
        console.warn(error);
      });
    },
  kitchensLoaded: function(){
    console.log("I should see a " + this.props.kitchens)
    this.setState({
      kitchens: this.props.kitchens,
      dataSource: this.state.dataSource.cloneWithRows(this.props.kitchens)
    })
  },
  getInitialState: function() {
    var ds = new ListView.DataSource({rowHasChanged: (row1, row2) => row1 !== row2});
    return {
      dataSource: ds.cloneWithRows(['row 1', 'row 2']),
    };
  },
  render: function() {
    console.log(this.props.kitchens)
      return (
        <ListView
          dataSource={this.state.dataSource}
          renderRow={(rowData) => <KitchenListItem id={rowData.id} name={rowData.name}></KitchenListItem>}
          />
      )
  },
  kitchenSelected:function(kitchen) {
    console.log("List can handle the kitchen selection here", kitchen.id)
  }
});
var styles = StyleSheet.create({
    container: {
        padding: 30,
        marginTop: 65,
        alignItems: "center"
    },
    heading: {
        marginBottom: 20,
        fontSize: 18,
        textAlign: "center",
        color: "#656565"
    },
    subheading: {
        color: "#cccccc"
    }
});

module.exports = KitchenList;
