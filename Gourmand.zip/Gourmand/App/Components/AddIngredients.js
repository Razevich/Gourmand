"use strict";

var React = require("react-native");
var {
    Component,
    StyleSheet,
    Text,
    View,
    ListView,
} = React;

class AddIngredientsView extends Component {

    var counter = 1

    constructor(props) {
        super(props);
        this.state = {
            username: this.props.username,
            password: this.props.password,
            token: this.props.token
        }
    }
};

var ListItem = React.createClass({

  render: function(){
    return (
      <View>
        <TextInput
          placeholder="Item"
          onChange={(event) => this.setState({itemText: event.nativeEvent.text})}
          value={this.state.itemText}
         />
         <TextInput
           placeholder="Qty"
           onChange={(event) => this.setState({qtyText: event.nativeEvent.text})}
           value={this.state.qtyText}
          />
      </View>
    )
  }
})

var IngredientsList = React.createClass({

  componentDidMount: function(){
    this.listLoaded
  },
  listLoaded: function(){
    this.setState({
      items: items,
      dataSource: this.props.dataSource.cloneWithRows(this.state.items)
    })
  },
  getInitialState: function() {
    var ds = new IntgredientsList.DataSource({rowHasChanged: (row1, row2) => row1 !== row2});
    return {
      dataSource: ds.cloneWithRows(['row 1', 'row 2']),
    };
  },
  render: function() {
      return (
          <ListView
            renderRow={(rowData) => <ListItem itemText={this.props.itemText} qtyText={this.props.qtyText}></ListItem> />
        }
      )
  },
  kitchenSelected:function(kitchen) {
    console.log("List can handle the kitchen selection here", item.id)
  }
});
var styles = StyleSheet.create({
    container: {
        padding: 30,
        marginTop: 65,
        alignItems: "center"
    },
    heading: {
        marginBottom: 20,
        fontSize: 18,
        textAlign: "center",
        color: "#656565"
    },
    subheading: {
        color: "#cccccc"
    }
});

module.exports = KitchenList;
